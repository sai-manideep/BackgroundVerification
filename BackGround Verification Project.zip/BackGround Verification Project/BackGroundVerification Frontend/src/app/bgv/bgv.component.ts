import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bgv',
  templateUrl: './bgv.component.html',
  styleUrls: ['./bgv.component.css']
})
export class BgvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
