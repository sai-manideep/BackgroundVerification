package com.capgemini.backgroundverification.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.when;

import org.aspectj.lang.annotation.Before;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.saml2.Saml2RelyingPartyProperties.Identityprovider.Verification;

import com.capgemini.backgroundverification.dao.VerificationRepository;
import com.capgemini.backgroundverification.service.VerificationService;

	@RunWith(MockitoJUnitRunner.class)
	public class BackgroundVerificationApplicationTests {
		@InjectMocks
		VerificationService service;
		
		@Mock
		@Autowired
		VerificationRepository dao;
		
		@Before(value = "")
		public void init() {
			MockitoAnnotations.initMocks(this);
		}
		
			@Test
		public void testsetStatus() {
			
			
				Verification v = new Verification(1,"Green");
				when(dao.save(v)).thenReturn(v);
				Verification v1=service.setStatus(v, 1);
				assertEquals(1,v1.getVerId());
				assertEquals("Green",v1.getStatus());
				
		} 
		
		@Test
		public void testcheckstatus() {
			Verification vtest = new Verification(1,"Green");
			Mockito.when(dao.getOne(1)).thenReturn(vtest);
			
			Verification v1 = service.checkStatus(1);
			assertEquals(v1,vtest);
			assertEquals("Green", v1.getStatus());
			assertNotEquals("xyz", v1.getStatus());
		}
}