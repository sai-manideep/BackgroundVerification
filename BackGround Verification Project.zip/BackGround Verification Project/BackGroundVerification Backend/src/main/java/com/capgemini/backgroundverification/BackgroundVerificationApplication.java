package com.capgemini.backgroundverification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgroundVerificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackgroundVerificationApplication.class, args);
	}

}
